/** Starter code for Splay Tree
 */
package rbk;

import java.util.Comparator;

public class SplayTree<T extends Comparable<? super T>> extends BinarySearchTree<T> {
    SplayTree() {
	super();
    }
}
